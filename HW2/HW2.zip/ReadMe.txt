All the programs will work as suggested in the pdf. Python3 is required
written part is in pdf named part5.pdf
output for part 4 is in file ouputAccuracy.txt


Jaykumar
110255934
