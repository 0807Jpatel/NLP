Name: Jaykumar Patel
Id: 110255934

Program was written in python 2.7

run part one   $ python LanguageModelBuilder.py -i </path/to/file>
run part two   $ python bigram-query.py </path/to/bigram.lm> </path/to/unigram.lm> word1 word2 <smoothing method>
run part three $ python perplexity.py </path/to/bigram.lm> <path/to/unigram.lm> </path/to/file>
